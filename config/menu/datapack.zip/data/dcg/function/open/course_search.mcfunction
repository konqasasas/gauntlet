dialog show @s dcg:course_search

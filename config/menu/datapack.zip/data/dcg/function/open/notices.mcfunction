dialog show @s dcg:notices

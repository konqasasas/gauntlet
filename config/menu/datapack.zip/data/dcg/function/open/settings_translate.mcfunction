dialog show @s dcg:settings_translate

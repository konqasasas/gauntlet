dialog show @s dcg:proto_gothic

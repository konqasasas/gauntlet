dialog show @s dcg:settings_profile

dialog show @s dcg:help

dialog show @s dcg:emote_pose

dialog show @s dcg:ledger_course

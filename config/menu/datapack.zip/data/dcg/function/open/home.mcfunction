dialog show @s dcg:home

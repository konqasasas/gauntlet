dialog show @s dcg:profile

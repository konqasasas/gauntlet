dialog show @s dcg:emote_motion

dialog show @s dcg:ranking

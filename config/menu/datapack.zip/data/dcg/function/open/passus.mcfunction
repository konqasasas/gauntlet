dialog show @s dcg:passus

dialog show @s dcg:settings

dialog show @s dcg:settings_sound_reset

dialog show @s dcg:ledger

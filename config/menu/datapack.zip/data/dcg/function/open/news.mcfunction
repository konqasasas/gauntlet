dialog show @s dcg:news

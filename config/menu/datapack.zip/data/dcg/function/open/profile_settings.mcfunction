dialog show @s dcg:profile_settings

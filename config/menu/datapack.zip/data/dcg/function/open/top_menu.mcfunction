dialog show @s dcg:top_menu

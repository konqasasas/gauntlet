dialog show @s dcg:gallery

dialog show @s dcg:course_select

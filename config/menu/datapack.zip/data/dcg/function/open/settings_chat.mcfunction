dialog show @s dcg:settings_chat

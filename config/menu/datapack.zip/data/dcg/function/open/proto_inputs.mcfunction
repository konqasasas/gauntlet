dialog show @s dcg:proto_inputs

dialog show @s dcg:emote

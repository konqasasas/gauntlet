dialog show @s dcg:settings_reset

dialog show @s dcg:proto_parts

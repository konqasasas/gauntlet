dialog show @s dcg:settings_ui_lang

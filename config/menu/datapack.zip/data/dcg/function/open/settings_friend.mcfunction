dialog show @s dcg:settings_friend
